package com.alivpn.app

import android.app.Application
import android.util.Log
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.SetupOptions
import java.util.Locale

class AliVpnApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        installCrashGuard()
        try {
            Libbox.setLocale(Locale.getDefault().toLanguageTag().replace("-", "_"))
            val base = filesDir.apply { mkdirs() }
            val working = (getExternalFilesDir(null) ?: filesDir).apply { mkdirs() }
            val temp = cacheDir.apply { mkdirs() }
            Libbox.setup(SetupOptions().also {
                it.basePath = base.absolutePath
                it.workingPath = working.absolutePath
                it.tempPath = temp.absolutePath
                it.fixAndroidStack = true
                it.logMaxLines = 2000
                it.debug = BuildConfig.DEBUG
            })
        } catch (t: Throwable) {
            Log.e("AliVPN", "libbox setup failed", t)
        }
    }

    /**
     * libbox's Go/JNI callbacks (openTun, getInterfaces, findConnectionOwner, ...) run
     * on native threads we don't control. Even with try/catch added around every
     * PlatformInterface method, this is a last-resort safety net: it guarantees an
     * unexpected exception on any thread gets logged instead of silently killing the
     * process with no trace, which is what "the app just closes" looks like from the
     * outside. The default handler still runs afterwards so normal crash reporting
     * (if any is added later) keeps working.
     */
    private fun installCrashGuard() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("AliVPN", "Uncaught exception on thread '${thread.name}'", throwable)
            previous?.uncaughtException(thread, throwable)
        }
    }
}
